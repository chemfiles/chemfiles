If you are not redirected automatically, follow the
`link to the fmt documentation <http://fmtlib.net/latest/>`_.
