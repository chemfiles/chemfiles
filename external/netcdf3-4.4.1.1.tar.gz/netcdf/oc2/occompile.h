/* Copyright 2009, UCAR/Unidata and OPeNDAP, Inc.
   See the COPYRIGHT file for more information. */

#ifndef OCCOMPILE_H
#define OCCOMPILE_H

extern OCerror occompile(OCstate* state, OCnode* xroot);

#endif /*OCCOMPILE_H*/
