## IUPAC Formats

[![Build Status](https://travis-ci.org/frodofine/iupac_formats.svg?branch=master)](https://travis-ci.org/frodofine/iupac_formats) [![Windows Build Status](https://ci.appveyor.com/api/projects/status/bsxi4ag360lh49xf/branch/master?svg=true)](https://ci.appveyor.com/project/frodofine/iupac-formats)

This project hosts the IUPAC formats INCHI and RINCHI.  It includes a new CMake build system.

The original source code is availible here:
https://www.inchi-trust.org/downloads/

The version of INCHI used is 1.05 and 1.00 for RINCHI.
