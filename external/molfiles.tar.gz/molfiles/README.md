# VMD molfile


VMD molfile plugin, extracted from the main repository, with CMake build system.

See http://www.ks.uiuc.edu/Research/vmd/plugins/molfile/ for the documentation.

Only CMake related issues are accepted, any other issues should go to the VMD mailling list.