#!/bin/bash

# This is the script used to generate the archive of the molfiles plugin
# used in chemfiles. Run it from the `plugins` directory of a VMD source code
# checkout or download, the output will be in chemfiles-molfiles

set -e

if [ $(uname) == "Darwin" ] ; then
    echo "Error: this script assume a case sensitive filesystem."
    echo "OS X filesystem is not by default. Please double check."
    exit 1
fi

OUT=molfiles
rm -rf $OUT
mkdir -p $OUT/src
mkdir -p $OUT/include

# Copy this script
cp ${BASH_SOURCE[0]} $OUT/cleanup.sh

# Get the include files
cp include/molfile_plugin.h $OUT/include
cp include/vmdplugin.h $OUT/include
cp include/vmdconio.h $OUT/include
chmod -x $OUT/include/*

cp molfile_plugin/LICENSE $OUT
chmod -x $OUT/LICENSE

cp molfile_plugin/src/*.h $OUT/src
cp molfile_plugin/src/*.hxx $OUT/src
cp molfile_plugin/src/*.cxx $OUT/src
cp molfile_plugin/src/*.c $OUT/src
# Do not use the capital C letter as extension for C++ ...
for file in molfile_plugin/src/*.C; do
    cp $file $OUT/src/$(basename ${file/.C/.cxx})
done
chmod -x $OUT/src/*

tar cf $OUT.tar $OUT
gzip $OUT.tar
rm -rf $OUT

echo $OUT.tar.gz created 

