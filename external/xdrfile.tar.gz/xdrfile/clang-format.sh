#!/usr/bin/sh

clang-format -i --style=file src/*.c include/*.h
