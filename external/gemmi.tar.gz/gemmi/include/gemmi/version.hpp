// Copyright 2017 Global Phasing Ltd.

#ifndef GEMMI_VERSION_HPP_
#define GEMMI_VERSION_HPP_

#define GEMMI_VERSION "0.4.0"

#endif
